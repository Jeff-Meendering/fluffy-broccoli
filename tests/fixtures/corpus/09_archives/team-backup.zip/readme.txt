Quarterly maintenance window is the first Sunday of each month.
Backups run at 02:00 and retain thirty days.
Escalate build failures to the on-call rota channel.
The staging cluster runs three nodes behind the load balancer.
